
  let  priceValue=4040;

  

exports.price=priceValue;